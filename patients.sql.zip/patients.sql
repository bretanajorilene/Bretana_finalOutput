-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql205.byetcluster.com
-- Generation Time: Nov 10, 2026 at 03:15 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43401914_patient_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birth_date` date NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `address` text NOT NULL,
  `blood_type` varchar(5) DEFAULT NULL,
  `diagnosis` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `first_name`, `last_name`, `gender`, `birth_date`, `phone`, `email`, `address`, `blood_type`, `diagnosis`, `status`, `created_at`) VALUES
(1, 'John', 'Santos', 'Male', '2000-05-15', '09123456789', 'john@gmail.com', 'Cebu City, Philippines', 'O+', 'Hypertension', 'Active', '2026-11-10 07:42:14'),
(3, 'James', 'Cruz', 'Male', '1995-03-10', '09345678901', 'james@gmail.com', 'Igbong Barotac Nuevo, Iloilo, Philippines', 'B+', 'Asthma', 'Inactive', '2026-11-10 07:42:14'),
(4, 'Angela', 'Garcia', 'Female', '2002-11-25', '09456789012', 'angela@gmail.com', 'Talisay Barotac Nuevo, Iloilo, Philippines', 'AB+', 'Migraine', 'Inactive', '2026-11-10 07:42:14'),
(5, 'Michael', 'Dela Cruz', 'Male', '1990-07-12', '09567890123', 'michael@gmail.com', 'Banate, Iloilo, Philippines', 'O-', 'Pneumonia', 'Active', '2026-11-10 07:42:14'),
(6, 'Jorilene', 'Bretana', 'Female', '2009-03-12', '09123456789', 'jorilene@gmail.com', 'Barotac Nuevo,Iloilo,Philippines', 'AB+', 'Acidic', 'Active', '2026-11-10 08:07:03'),
(7, 'Shei', 'Loy', 'Male', '1997-04-13', '09098763461', 'loyshei10@gmail.com', 'Baras, Barotac Nuevo, Iloilo, Philippines', 'A+', 'Stroke', 'Active', '2026-11-10 08:14:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
